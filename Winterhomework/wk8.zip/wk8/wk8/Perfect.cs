﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wk8
{
    class Perfect:ThingTotal
    {
        public string PerfectName { get; set; }
        public decimal PerfectOne { get; set; }
    }
}
