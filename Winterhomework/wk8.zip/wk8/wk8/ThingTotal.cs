﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wk8
{
    class ThingTotal
    {
        public decimal AtomPen { get; set; }
        public decimal Pen { get; set; }
        public decimal Eraser { get; set; }
        public decimal Ruler { get; set; }
        public decimal LiWhite { get; set; }
    }
}
