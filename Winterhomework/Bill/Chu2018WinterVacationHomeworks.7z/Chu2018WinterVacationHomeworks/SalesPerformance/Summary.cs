﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalesPerformance
{
    public class Summary
    {
        public string Salesman { get; set; }
        public string Item { get; set; }
        public int Amount { get; set; }
    }
    
}
